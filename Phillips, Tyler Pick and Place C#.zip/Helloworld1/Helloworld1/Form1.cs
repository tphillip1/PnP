﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Emgu.CV;
using Emgu.CV.CvEnum;
using Emgu.CV.Structure;
using Emgu.CV.Util;


namespace Helloworld1
{
    public partial class Form1 : Form

    {
        private VideoCapture _capture;
        private Thread _captureThread;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            _capture = new VideoCapture(1);// 0 for onboard webcam, 1 for usb webcam
            _captureThread = new Thread(DisplayWebcam);
            _captureThread.Start();
            Debug.WriteLine("Method2");
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            _captureThread.Abort();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        
        private void DisplayWebcam()
        {
            Debug.Print("test");

            while (_capture.IsOpened)
            {
               
                // Mat frame = _capture.QueryFrame();
                // CvInvoke.Resize(frame, frame, sourcePictureBox.Size);
                //Image<Bgr, byte> img = frame.ToImage<Bgr, Byte>();
                // frame maintenance
                Mat sourceFrame = _capture.QueryFrame();
                // resize to PictureBox aspect ratio
                int newHeight = (sourceFrame.Size.Height * sourcePictureBox.Size.Width) / sourceFrame.Size.Width;
                Size newSize = new Size(sourcePictureBox.Size.Width, newHeight);
                CvInvoke.Resize(sourceFrame, sourceFrame, newSize);
                // display the image in the source PictureBox
                sourcePictureBox.Image = sourceFrame.Bitmap;
                // copy the source image so we can display a copy with artwork without editing the original:
                Mat sourceFrameWithArt = sourceFrame.Clone();
                // create an image version of the source frame, will be used when warping the image
                Image<Bgr, byte> sourceFrameWarped = sourceFrame.ToImage<Bgr, byte>();
                // Isolating the ROI: convert to a gray, apply binary threshold:
                Image<Gray, byte> grayImg = sourceFrame.ToImage<Gray, byte>().ThresholdBinary(new Gray(125), new
                Gray(255));
                
                using (VectorOfVectorOfPoint contours = new VectorOfVectorOfPoint())
                {
                    // Build list of contours
                    CvInvoke.FindContours(grayImg, contours, null, RetrType.List, ChainApproxMethod.ChainApproxSimple);
                    // Selecting largest contour
                    if (contours.Size > 0)
                    {
                        double maxArea = 0;
                        int chosen = 0;
                        for (int i = 0; i < contours.Size; i++)
                        {
                            VectorOfPoint contour = contours[i];
                            double area = CvInvoke.ContourArea(contour);
                            if (area > maxArea)
                            {
                                maxArea = area;
                                chosen = i;
                            }
                        }
                        // Getting minimal rectangle which contains the contour
                        Rectangle boundingBox = CvInvoke.BoundingRectangle(contours[chosen]);
                        // Draw on the display frame
                        MarkDetectedObject(sourceFrameWithArt, contours[chosen], boundingBox, maxArea);
                        // Create a slightly larger bounding rectangle, we'll set it as the ROI for later warping
                        sourceFrameWarped.ROI = new Rectangle((int)Math.Min(0, boundingBox.X - 30),
                        (int)Math.Min(0, boundingBox.Y - 30),
                        (int)Math.Max(sourceFrameWarped.Width - 1, boundingBox.X +
                        boundingBox.Width + 30),
                        (int)Math.Max(sourceFrameWarped.Height - 1, boundingBox.Y +
                        boundingBox.Height + 30));
                        // Display the version of the source image with the added artwork, simulating ROI focus:
                        roiPictureBox.Image = sourceFrameWithArt.Bitmap;

                        Mat warpedPicture = WarpImage(sourceFrameWarped, contours[chosen]).Mat;
                        // Warp the image, output it
                        warpedPictureBox.Image = warpedPicture.Bitmap; //WarpImage(sourceFrameWarped, contours[chosen]).Bitmap;


                        //new code
                        // Sample for gaussian blur:
                        var blurredImage = new Mat();
                        var cannyImage = new Mat();
                        var decoratedImage = new Mat();
                        //img = decoratedImage.Clone().ToImage<Bgr, byte>();

                        //Image<Bgr, byte> tempImage = img.Clone();

                        CvInvoke.GaussianBlur(warpedPicture, blurredImage, new Size(3, 3), 0);
                        // convert to B/W
                        CvInvoke.CvtColor(blurredImage, blurredImage, typeof(Bgr), typeof(Gray));
                        // apply canny:
                        // NOTE: Canny function can frequently create duplicate lines on the same shape
                        // depending on blur amount and threshold values, some tweaking might be needed.
                        // You might also find that not using Canny and instead using FindContours on
                        // a binary-threshold image is more accurate.
                        CvInvoke.Canny(blurredImage, cannyImage, 150, 255);
                        // make a copy of the canny image, convert it to color for decorating:
                        CvInvoke.CvtColor(cannyImage, decoratedImage, typeof(Gray), typeof(Bgr));
                        // find contours:
                        using (VectorOfVectorOfPoint contours1 = new VectorOfVectorOfPoint())
                        {
                            // Build list of contours
                            CvInvoke.FindContours(cannyImage, contours1, null, RetrType.List,
                                ChainApproxMethod.ChainApproxSimple);
                            for (int i = 0; i < contours1.Size; i++)
                            {
                                VectorOfPoint contour = contours1[i];
                                CvInvoke.Polylines(decoratedImage, contour, true, new Bgr(Color.Red).MCvScalar);
                            }
                           // MessageBox.Show($"There are {contours1.Size} contours detected");
                            Invoke(new Action(() => { label5.Text = $"Contours: {contours1.Size}"; }));
                        }
                        
                        // output images:
                        warpedPictureBox.Image = warpedPicture.Bitmap;
                        OutputBox.Image = decoratedImage.Bitmap;
                        
                    }
                }

        }
     }
        private static Image<Bgr, Byte> WarpImage(Image<Bgr, byte> frame, VectorOfPoint contour)
        {
            // set the output size:
            var size = new Size(frame.Width, frame.Height);
            using (VectorOfPoint approxContour = new VectorOfPoint())
            {
                CvInvoke.ApproxPolyDP(contour, approxContour, CvInvoke.ArcLength(contour, true) * 0.05, true);
                // get an array of points in the contour
                Point[] points = approxContour.ToArray();
                // if array length isn't 4, something went wrong, abort warping process (for demo, draw points instead)
                if (points.Length != 4)
                {
                    for (int i = 0; i < points.Length; i++)
                    {
                        frame.Draw(new CircleF(points[i], 5), new Bgr(Color.Red), 5);
                    }
                    return frame;
                }
                IEnumerable<Point> query = points.OrderBy(point => point.Y).ThenBy(point => point.X);
                PointF[] ptsSrc = new PointF[4];
                PointF[] ptsDst = new PointF[] { new PointF(0, 0), new PointF(size.Width - 1, 0), new PointF(0, size.Height - 1),
                new PointF(size.Width - 1, size.Height - 1) };
                for (int i = 0; i < 4; i++)
                {
                    ptsSrc[i] = new PointF(query.ElementAt(i).X, query.ElementAt(i).Y);
                }
                using (var matrix = CvInvoke.GetPerspectiveTransform(ptsSrc, ptsDst))
                {
                    using (var cutImagePortion = new Mat())
                    {
                        CvInvoke.WarpPerspective(frame, cutImagePortion, matrix, size, Inter.Cubic);
                        return cutImagePortion.ToImage<Bgr, Byte>();
                    }
                }
            }
        }
        private static void MarkDetectedObject(Mat frame, VectorOfPoint contour, Rectangle boundingBox, double area)
        {
            Color lineColor = Color.Blue;
            // Drawing contour and box around it
           
            //compare area of the shape detected to the area drawn around the shape to determine the shape
            double contourArea = CvInvoke.ContourArea(contour);
            double totArea = boundingBox.Height * boundingBox.Width;
            double perArea =  contourArea / totArea;

            if (perArea > .75)
            {
                //detect square
                lineColor = Color.Red;
            }
            else
            {
                //detect triangle
                lineColor = Color.Green;
            }

            CvInvoke.Polylines(frame, contour, true, new Bgr(lineColor).MCvScalar);
            CvInvoke.Rectangle(frame, boundingBox, new Bgr(lineColor).MCvScalar);

            // Write information next to marked object
            Point center = new Point(boundingBox.X + boundingBox.Width / 2, boundingBox.Y + boundingBox.Height / 2);
            var info = new string[] {
            $"Area: {area}",
               $"Position: {center.X}, {center.Y}"
                };
            WriteMultilineText(frame, info, new Point(center.X, boundingBox.Bottom + 12));
        }
        private static void WriteMultilineText(Mat frame, string[] lines, Point origin)
        {
            for (int i = 0; i < lines.Length; i++)
            {
                int y = i * 10 + origin.Y; // Moving down on each line
                CvInvoke.PutText(frame, lines[i], new Point(origin.X, y),
                FontFace.HersheyPlain, 0.8, new Bgr(Color.Red).MCvScalar);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void OutputBox_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}